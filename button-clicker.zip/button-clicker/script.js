function custom() {
    // we can include more code here if we want to
    console.log("this message is coming from script.js");
}
